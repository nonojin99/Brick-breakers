# BRICK ORBIT — 벽돌깨기 (Ballz 스타일)

Node.js + Supabase 기반 벽돌깨기. 솔로 모드 / 리더보드 / **실시간 1v1 랭킹전** 지원.

## 게임 규칙
- 마우스로 각도 조준(10°~170°) → 클릭 발사. 구슬은 벽·벽돌에 반사
- 벽돌은 표시된 HP만큼 맞으면 파괴 (HP는 라운드에 비례해 상승)
- 턴마다 벽돌 전체가 1칸 하강 + 최상단에 새 줄 생성
- 아이템: `+1`(구슬 증가) · `↟`(관통) · `Y`(분열) · `✸`(폭파 3×3)
- 벽돌이 발사선(빨간 점선)에 닿으면 게임오버
- **랭킹전**: 같은 시드로 두 명이 동시 플레이 → 먼저 죽는 쪽이 패배

## 실행 (솔로 모드는 이것만으로 동작)
```powershell
npm install
npm start        # → http://localhost:3000
```

## Supabase 설정 (리더보드 + 랭킹전)
1. https://supabase.com 에서 무료 프로젝트 생성
2. **Authentication → Sign In / Up → Anonymous sign-ins 활성화** (필수)
3. SQL Editor에 `supabase-schema.sql` 내용 붙여넣고 실행
4. Settings → API 에서 Project URL / anon key 복사
5. `public/js/config.js` 에 붙여넣기:
   ```js
   export const SUPABASE_URL = 'https://xxxx.supabase.co';
   export const SUPABASE_ANON_KEY = 'eyJ...';
   ```
6. 서버 재시작 후 새로고침 → 랭킹전/리더보드 버튼 활성화

### 랭킹전 혼자 테스트하기
브라우저 탭 2개로 `localhost:3000` 열고 양쪽에서 "랭킹전" 클릭.
(익명 세션이 브라우저 단위라, 완전한 별도 유저 테스트는 일반 창 + 시크릿 창 사용)

## 테스트 (엔진 콘솔 검증, 51개)
```powershell
npm test
```
- `test/sim.js` — 물리: 반사/타격/귀환 (16)
- `test/turn.js` — 턴 사이클: 하강/생성/게임오버/시드 동기화 (18)
- `test/items.js` — 아이템: +1/관통/분열/폭파 (17)

## 구조
```
server.js                  Express 정적 서버 (게임 로직 없음)
supabase-schema.sql        DB 스키마 + RLS
public/
  index.html               UI 레이아웃 (HUD/메뉴/오버레이)
  js/engine.js             ★ 순수 게임 엔진 (DOM 무관, 시드 PRNG)
  js/renderer.js           Canvas 렌더링 전용
  js/main.js               게임 루프/입력/솔로·랭킹전 흐름
  js/net.js                Supabase (인증/리더보드/Realtime 매치)
  js/config.js             본인 Supabase 키 입력
test/                      콘솔 검증 스크립트
```

## 설계 노트
- **엔진/렌더러 완전 분리**: engine.js는 브라우저 없이 Node에서 그대로 테스트됨
- **시드 PRNG (mulberry32)**: `Math.random` 미사용 → 같은 시드면 벽돌·아이템
  배치가 완전 동일. 랭킹전은 시드 하나만 공유하고 각자 로컬 시뮬레이션,
  네트워크로는 `{round, ballCount}` 요약만 브로드캐스트
- **매치메이킹**: `matches` 테이블에서 waiting 방 검색 → 조건부 UPDATE로
  동시 참가 경합 방지 → 이후 통신은 Supabase Realtime Broadcast 채널
- 알려진 한계: 매치 중 상대 이탈 감지 없음(다음 확장으로 Presence 추천),
  점수 서버 검증 없음(클라이언트 신뢰)
