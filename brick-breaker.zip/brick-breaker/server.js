// server.js — 정적 파일 서버. 게임 로직은 전부 클라이언트, Supabase는 직접 통신.
import express from 'express';

const app = express();
app.use(express.static('public'));

const PORT = process.env.PORT || 3000;
app.listen(PORT, () => {
  console.log(`벽돌깨기 서버 실행 중 → http://localhost:${PORT}`);
});
