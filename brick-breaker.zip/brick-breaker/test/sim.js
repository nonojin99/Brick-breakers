// test/sim.js — 1단계 검증 시뮬레이션. 실행: node test/sim.js
import { Engine, createRng, CONFIG } from '../public/js/engine.js';

let pass = 0, fail = 0;
function assert(name, cond, detail = '') {
  if (cond) { pass++; console.log(`  ✅ ${name}`); }
  else      { fail++; console.log(`  ❌ ${name} ${detail}`); }
}

function runUntilTurnOver(e, maxSteps = 5000) {
  const all = [];
  for (let i = 0; i < maxSteps && !e.isTurnOver(); i++) all.push(...e.step());
  return all;
}

// ── 검증 1: 수직 발사 → 벽돌 타격(HP 감소) → 바닥 귀환, 귀환 x = 발사 x ──
console.log('\n[1] 수직 발사 → 타격 → 귀환');
{
  const e = new Engine();
  e.setBrick(2, 5, { type: 'normal', hp: 3 }); // 발사선 정위쪽 (launchX=352 → col 5)
  e.launch(90, 1);
  const ev = runUntilTurnOver(e);
  const hit = ev.find((v) => v.t === 'hit');
  const ret = ev.find((v) => v.t === 'return');
  assert('벽돌 타격 발생', !!hit);
  assert('HP 3 → 2 감소', hit && hit.hp === 2, `hp=${hit?.hp}`);
  assert('벽돌 잔존 (hp 2)', e.grid[2][5]?.hp === 2);
  assert('바닥 귀환', !!ret);
  assert('수직 발사라 귀환 x ≈ 발사 x', ret && Math.abs(ret.x - 352) < 1, `x=${ret?.x}`);
}

// ── 검증 2: 45° 발사 → 우측 벽 반사 ──
console.log('\n[2] 45° 발사 → 우측 벽 반사');
{
  const e = new Engine(); // 벽돌 없음
  e.launch(45, 1);
  const ev = runUntilTurnOver(e);
  const walls = ev.filter((v) => v.t === 'wall').map((v) => v.side);
  assert('우측 벽 반사 발생', walls.includes('right'), `walls=${walls}`);
  assert('천장 반사 발생', walls.includes('top'));
  assert('최종 귀환', ev.some((v) => v.t === 'return'));
}

// ── 검증 3: HP 2 벽돌 = 정확히 2회 타격에 파괴 ──
console.log('\n[3] HP 2 벽돌 2회 타격 파괴');
{
  const e = new Engine();
  e.setBrick(0, 5, { type: 'normal', hp: 2 }); // 천장 붙임 → 수직발사 시 벽돌-바닥 왕복
  e.launch(90, 1);
  // 1회 타격 후 바닥 귀환 → 재발사로 2회째
  runUntilTurnOver(e);
  assert('1회 타격 후 hp 1', e.grid[0][5]?.hp === 1, `hp=${e.grid[0][5]?.hp}`);
  e.launch(90, 1);
  const ev2 = runUntilTurnOver(e);
  assert('2회 타격에 파괴 이벤트', ev2.some((v) => v.t === 'destroy'));
  assert('그리드에서 제거됨', e.grid[0][5] === null);
}

// ── 검증 4: 시드 PRNG 재현성 (멀티플레이 필수 조건) ──
console.log('\n[4] 시드 PRNG 재현성');
{
  const a = createRng(12345), b = createRng(12345), c = createRng(99999);
  const seqA = Array.from({ length: 5 }, a);
  const seqB = Array.from({ length: 5 }, b);
  const seqC = Array.from({ length: 5 }, c);
  assert('같은 시드 = 같은 수열', JSON.stringify(seqA) === JSON.stringify(seqB));
  assert('다른 시드 = 다른 수열', JSON.stringify(seqA) !== JSON.stringify(seqC));
  assert('0~1 범위', seqA.every((v) => v >= 0 && v < 1));
}

// ── 검증 5: 다중 구슬 (3개) 전부 귀환 → 턴 종료 ──
console.log('\n[5] 구슬 3개 발사 → 전원 귀환 시 턴 종료');
{
  const e = new Engine();
  e.setBrick(3, 5, { type: 'normal', hp: 10 });
  e.launch(75, 3);
  const ev = runUntilTurnOver(e);
  const returns = ev.filter((v) => v.t === 'return');
  assert('귀환 3회', returns.length === 3, `returns=${returns.length}`);
  assert('턴 종료 상태', e.isTurnOver());
}

console.log(`\n결과: ${pass} 통과 / ${fail} 실패`);
process.exit(fail ? 1 : 0);
