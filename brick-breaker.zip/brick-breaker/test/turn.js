// test/turn.js — 2단계 검증. 실행: node test/turn.js
import { Engine } from '../public/js/engine.js';

let pass = 0, fail = 0;
function assert(name, cond, detail = '') {
  if (cond) { pass++; console.log(`  ✅ ${name}`); }
  else      { fail++; console.log(`  ❌ ${name} ${detail}`); }
}
const runTurn = (e) => { let i = 0; while (!e.isTurnOver() && i++ < 5000) e.step(); };
const brickCount = (e) => e.grid.flat().filter(Boolean).length;

// ── 검증 1: startGame → 최상단에만 벽돌 생성 ──
console.log('\n[1] startGame: 첫 행 생성');
{
  const e = new Engine();
  e.startGame(42);
  assert('round = 1', e.round === 1);
  assert('최상단 행에 벽돌 존재', e.grid[0].some(Boolean));
  assert('나머지 행은 비어 있음', e.grid.slice(1).flat().every((b) => b === null));
}

// ── 검증 2: descend → 전 벽돌이 정확히 1칸 하강 ──
console.log('\n[2] 하강: 벽돌 위치 1칸 이동');
{
  const e = new Engine();
  e.startGame(42);
  const before = e.grid[0].map((b) => (b ? b.hp : null));
  e.descend();
  const after = e.grid[1].map((b) => (b ? b.hp : null));
  assert('row0 벽돌이 row1로 그대로 이동', JSON.stringify(before) === JSON.stringify(after));
  assert('row0은 비워짐', e.grid[0].every((b) => b === null));
  assert('게임오버 아님', !e.gameOver);
}

// ── 검증 3: 턴 사이클 통합 — endTurn마다 round 증가, 신규 행 생성 ──
console.log('\n[3] 턴 사이클: 발사 → 귀환 → endTurn');
{
  const e = new Engine();
  e.startGame(7);
  e.launch(90, 1);
  runTurn(e);
  const ok = e.endTurn();
  assert('endTurn 성공', ok === true);
  assert('round 1 → 2', e.round === 2);
  assert('신규 행이 최상단에 생성됨', e.grid[0].some(Boolean));
  const newBricks = e.grid[0].filter((c) => c && c.type !== 'item');
  assert('신규 행 벽돌 HP는 round 반영 (2 또는 4)', newBricks.every((b) => b.hp === 2 || b.hp === 4),
    `hps=${newBricks.map((b) => b.hp)}`);
}

// ── 검증 4: 첫 귀환 구슬 x = 다음 턴 발사 위치 ──
console.log('\n[4] 발사 위치 갱신');
{
  const e = new Engine();
  e.startGame(7);
  e.launch(30, 1); // 대각 발사 (사전 확인: seed 7에서 귀환 x ≈ 290.8, 발사점과 상이)
  runTurn(e);
  const retX = e.nextLaunchX;
  assert('귀환 x 기록됨 (발사점과 다름)', retX !== null && Math.abs(retX - 352) > 5, `retX=${retX}`);
  e.endTurn();
  assert('다음 발사 위치 = 귀환 x', e.launchX === retX);
}

// ── 검증 5: 게임오버 — 벽돌이 최하단 도달 ──
console.log('\n[5] 게임오버 판정');
{
  const e = new Engine();
  e.startGame(7);
  // 벽돌을 안 깨고 턴만 넘기면 rows-1 = 11턴 하강 후 최하단 도달
  let turns = 0;
  while (!e.gameOver && turns < 50) {
    e.launch(90 + (turns % 2 ? 30 : -30), 0); // 구슬 0개 = 즉시 턴 종료 (벽돌 안 깸)
    e.endTurn();
    turns++;
  }
  assert('게임오버 발생', e.gameOver);
  assert('11턴째 하강에서 최하단 도달', turns === 11, `turns=${turns}`);
  assert('게임오버 후 endTurn 거부', e.endTurn() === false);
}

// ── 검증 6: 멀티플레이 동기화 — 같은 시드 두 엔진 = N턴 후 동일 그리드 ──
console.log('\n[6] 시드 동기화: 두 엔진 5턴 동일성');
{
  const a = new Engine(), b = new Engine();
  a.startGame(2026); b.startGame(2026);
  for (let t = 0; t < 5; t++) {
    for (const e of [a, b]) { e.launch(70, 2); runTurn(e); e.endTurn(); }
  }
  assert('5턴 후 그리드 완전 동일', a.render() === b.render());
  assert('round 동일 (6)', a.round === 6 && b.round === 6);
  assert('벽돌 수 동일', brickCount(a) === brickCount(b), `${brickCount(a)} vs ${brickCount(b)}`);
}

console.log(`\n결과: ${pass} 통과 / ${fail} 실패`);
process.exit(fail ? 1 : 0);
