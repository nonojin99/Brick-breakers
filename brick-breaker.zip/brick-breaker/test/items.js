// test/items.js — 4단계(아이템·특수구슬) 검증. 실행: node test/items.js
import { Engine } from '../public/js/engine.js';

let pass = 0, fail = 0;
function assert(name, cond, detail = '') {
  if (cond) { pass++; console.log(`  ✅ ${name}`); }
  else      { fail++; console.log(`  ❌ ${name} ${detail}`); }
}
const runTurn = (e) => { let i = 0; while (!e.isTurnOver() && i++ < 8000) e.step(); };
const fresh = () => { const e = new Engine(); e.grid = e.emptyGrid(); e.round = 1; e.gameOver = false; e.ballCount = 1; return e; };

// ── 검증 1: 구슬+1 — 획득 시 ballCount 증가, 다음 발사에 반영 ──
console.log('\n[1] ball+1 아이템');
{
  const e = fresh();
  e.grid[3][5] = { type: 'item', kind: 'ball+1' }; // 발사선 정위쪽
  e.launch(90);
  runTurn(e);
  assert('획득 이벤트 발생', e.events.some((v) => v.t === 'item' && v.kind === 'ball+1'));
  assert('ballCount 1 → 2', e.ballCount === 2);
  assert('아이템 셀 제거됨', e.grid[3][5] === null);
  e.launch(90); // count 미지정 → ballCount 사용
  assert('다음 발사 구슬 2개', e.balls.length === 2);
}

// ── 검증 2: 아이템은 반사 없이 통과 (획득 후 계속 위로 진행) ──
console.log('\n[2] 아이템 통과 (반사 없음)');
{
  const e = fresh();
  e.grid[5][5] = { type: 'item', kind: 'ball+1' };
  e.grid[1][5] = { type: 'normal', hp: 1 }; // 아이템 뒤의 벽돌
  e.launch(90);
  runTurn(e);
  assert('아이템 획득', e.events.some((v) => v.t === 'item'));
  assert('아이템 너머 벽돌도 타격됨 = 통과 확인', e.events.some((v) => v.t === 'hit'));
}

// ── 검증 3: 관통 — 반사 없이 일직선상 벽돌 전부 대미지 ──
console.log('\n[3] pierce (관통)');
{
  const e = fresh();
  e.grid[7][5] = { type: 'item', kind: 'pierce' };
  e.grid[4][5] = { type: 'normal', hp: 1 };
  e.grid[2][5] = { type: 'normal', hp: 1 };
  e.grid[0][5] = { type: 'normal', hp: 1 };
  e.launch(90);
  runTurn(e);
  const destroyed = e.events.filter((v) => v.t === 'destroy').length;
  assert('일직선 벽돌 3개 전부 파괴 (반사 없이 통과)', destroyed === 3, `destroyed=${destroyed}`);
}

// ── 검증 4: 분열 — 구슬 1개 → 2개, 전부 귀환해야 턴 종료 ──
console.log('\n[4] split (분열)');
{
  const e = fresh();
  e.grid[6][5] = { type: 'item', kind: 'split' };
  e.launch(90);
  runTurn(e);
  const returns = e.events.filter((v) => v.t === 'return').length;
  assert('분열 획득', e.events.some((v) => v.t === 'item' && v.kind === 'split'));
  assert('귀환 2회 (1개 → 2갈래)', returns === 2, `returns=${returns}`);
  assert('턴 정상 종료', e.isTurnOver());
}

// ── 검증 5: 폭파 — 획득 지점 3×3 대미지 ──
console.log('\n[5] bomb (폭파)');
{
  const e = fresh();
  e.grid[5][5] = { type: 'item', kind: 'bomb' };
  // 3×3 범위 안 4개 + 범위 밖 1개
  e.grid[4][4] = { type: 'normal', hp: 1 };
  e.grid[4][6] = { type: 'normal', hp: 1 };
  e.grid[6][4] = { type: 'normal', hp: 2 };
  e.grid[5][6] = { type: 'normal', hp: 1 };
  e.grid[2][2] = { type: 'normal', hp: 1 }; // 범위 밖
  e.launch(90);
  runTurn(e);
  assert('범위 내 hp1 벽돌들 파괴', !e.grid[4][4] && !e.grid[4][6] && !e.grid[5][6]);
  assert('범위 내 hp2 벽돌은 hp1 잔존', e.grid[6][4]?.hp === 1, `hp=${e.grid[6][4]?.hp}`);
  assert('범위 밖 벽돌 무피해', e.grid[2][2]?.hp === 1);
}

// ── 검증 6: 하강 시 최하단 아이템은 소멸, 게임오버 아님 ──
console.log('\n[6] 최하단 아이템 처리');
{
  const e = fresh();
  e.grid[10][3] = { type: 'item', kind: 'ball+1' }; // 하강하면 최하단(11)
  e.descend();
  assert('아이템 소멸', e.grid[11][3] === null);
  assert('게임오버 아님 (아이템은 판정 제외)', !e.gameOver);
}

// ── 검증 7: 아이템 포함 시드 동기화 (멀티플레이 회귀) ──
console.log('\n[7] 아이템 포함 시드 재현성');
{
  const a = new Engine(), b = new Engine();
  a.startGame(777); b.startGame(777);
  for (let t = 0; t < 6; t++) {
    for (const e of [a, b]) { e.launch(65, e.ballCount); runTurn(e); e.endTurn(); }
  }
  assert('6턴 후 그리드 동일 (아이템 위치 포함)', a.render() === b.render());
  assert('ballCount 동일', a.ballCount === b.ballCount, `${a.ballCount} vs ${b.ballCount}`);
}

console.log(`\n결과: ${pass} 통과 / ${fail} 실패`);
process.exit(fail ? 1 : 0);
