// config.js — 본인 Supabase 프로젝트 값으로 교체하세요.
// 비워두면 솔로 모드만 동작하고 온라인 기능(리더보드/랭킹전)은 비활성화됩니다.
// Supabase 대시보드 → Settings → API 에서 확인
export const SUPABASE_URL = '';      // 예: 'https://xxxx.supabase.co'
export const SUPABASE_ANON_KEY = ''; // anon public key (클라이언트 노출 OK)
