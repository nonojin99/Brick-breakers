-- supabase-schema.sql
-- Supabase 대시보드 → SQL Editor 에 붙여넣고 실행하세요.
-- 사전 준비: Authentication → Sign In / Up → Anonymous sign-ins 활성화

-- ── 리더보드 ──────────────────────────────────────────────
create table if not exists scores (
  id uuid primary key default gen_random_uuid(),
  user_id uuid references auth.users not null,
  nickname text,
  round int not null,
  balls int,
  created_at timestamptz default now()
);

alter table scores enable row level security;

create policy "scores: 누구나 조회" on scores
  for select using (true);

create policy "scores: 본인만 등록" on scores
  for insert with check (auth.uid() = user_id);

-- ── 랭킹전 매치 ────────────────────────────────────────────
create table if not exists matches (
  id uuid primary key default gen_random_uuid(),
  seed bigint not null,               -- 양쪽 동일 벽돌 생성용 시드
  status text not null default 'waiting',  -- waiting | playing | done
  p1 uuid references auth.users not null,
  p2 uuid references auth.users,
  winner uuid,
  created_at timestamptz default now()
);

alter table matches enable row level security;

create policy "matches: 로그인 유저 조회" on matches
  for select using (auth.role() = 'authenticated');

create policy "matches: 본인이 p1으로 생성" on matches
  for insert with check (auth.uid() = p1);

create policy "matches: 참가자만 수정" on matches
  for update using (auth.uid() = p1 or p2 is null or auth.uid() = p2);

create policy "matches: 방장이 대기방 삭제" on matches
  for delete using (auth.uid() = p1 and status = 'waiting');

-- 매치메이킹 조회 성능
create index if not exists idx_matches_waiting on matches (status, created_at);
